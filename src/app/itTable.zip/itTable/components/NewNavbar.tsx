import { setInitialUsersArray, setSearchText } from "@/app/redux/actions";
import { RootState } from "@/app/rootStates/rootState";
import { ItTeamType } from "@/app/types/important";
import { Input } from "@nextui-org/input";
import { Select, SelectItem } from "@nextui-org/select";
import React, { useCallback, useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";

const NewNavbar = () => {
  const dispatch = useDispatch();
  const alphabeticallyFiltring = useSelector(
    (state: RootState) => state.name.sorting
  );
  const elementsFiltring = useSelector(
    (state: RootState) => state.name.sortingTypeTwo
  );

  const itUsers = useSelector(
    (state: RootState) => state.name.initialUsersArray
  );

  const searchTextInput = useSelector((state: RootState) =>
    state.name.searchText?.toLowerCase()
  );

  const [filterUserButton, setFilterUserButton] = useState<number>(0);
  const [filterElementsButton, setFilterElementsButton] = useState<number>(0);

  const search = (parameter: string, userList: ItTeamType[]): ItTeamType[] => {
    //setSearchText(event);
    //const searchList = [...newItUsers];

    //const searchTerm = event.target.value.toLowerCase();
    //setSearchText(searchTerm);
    dispatch(setSearchText(parameter.trim()));
    //console.log("Wpisane", searchTextInput);
    // if (searchTerm !== "") {
    //   setIsSearchActivated(true);
    // } else {
    //   setIsSearchActivated(false);
    // }

    // const filteredData = searchList.filter((element) => {
    //   const matchesTerm = () =>
    //     element.firstName.toLowerCase().trim().includes(parameter) ||
    //     element.lastName.toLowerCase().trim().includes(parameter) ||
    //     element.phoneNumber.toLowerCase().trim().includes(parameter) ||
    //     element.email.toLowerCase().trim().includes(parameter) ||
    //     element.weekNo.toLowerCase().trim().includes(parameter) ||
    //     element.timeWork.toLowerCase().trim().includes(parameter);

    //   if (parameter !== "" && parameter !== null && matchesTerm()) {
    //     console.log("Wpisano", parameter);
    //     return element;
    //   } else if (parameter === "") {
    //     return element;
    //   }
    // });

    const filteredData = userList.reduce((acc: ItTeamType[], user) => {
      const matchesTerm = () =>
        user.firstName.toLowerCase().includes(parameter.trim()) ||
        user.lastName.toLowerCase().trim().includes(parameter.trim()) ||
        user.phoneNumber.toLowerCase().trim().includes(parameter.trim()) ||
        user.email.toLowerCase().trim().includes(parameter.trim()) ||
        user.weekNo.toLowerCase().trim().includes(parameter.trim()) ||
        user.timeWork.toLowerCase().trim().includes(parameter.trim());

      if (matchesTerm()) {
        console.log("Wpisano", parameter);
        acc.push(user);
        console.log("Akumulator", user);
      } else if (parameter.trim() === "") {
        console.log("PUSTE");
        acc.push(user);
        console.log("Akumulator", user);
      }
      return acc;
    }, []);

    //console.log("Tekst1", searchTextInput);
    //console.log("Tekst2", parameter);
    console.log("Dane", filteredData);
    // else if (isElementsClicked || (isSearchActivated && matchesTerm())) {
    //     console.log("Kliknieto&Wpisano");
    //     return element;
    //   }
    // const finalData = filteredData;
    // console.log("FINAL", finalData);
    // if (isListTwo === 0) {
    //   finalData = searchList.slice(0, 5);
    // } else if (isListTwo === 1) {
    //   finalData = searchList.slice(0, 8);
    // } else if (isListTwo === 2) {
    //   return finalData;
    // }

    // setPassedAllData(filteredData);
    //dispatch(setInitialUsersArray(filteredData));
    return filteredData;
  };
  const filterByElements = useCallback(
    (id: number) => {
      let changedList = [...itUsers];
      setFilterElementsButton(id);
      if (id === 0 && filterElementsButton == 0) {
        changedList = changedList.filter((_, index) => index < 4);
        // dispatch(
        //   setInitialUsersArray([...itUsers].filter((_, index) => index < 4))
        // );
        console.log("Przelacznik", filterElementsButton);
      }
      if (id === 1 && filterElementsButton == 1) {
        changedList = changedList.filter((_, index) => index < 8);
        // dispatch(
        //   setInitialUsersArray([...itUsers].filter((_, index) => index < 8))
        // );
        console.log("Przelacznik", filterElementsButton);
        //console.log("LISTA", changedList);
      }
      if (id === 2 && filterElementsButton == 2) {
        changedList = [...itUsers];
        // dispatch(setInitialUsersArray([...itUsers]));
        console.log("Przelacznik", filterElementsButton);
        //console.log("LISTA", changedList);
      }
      dispatch(setInitialUsersArray(changedList));
    },
    [itUsers, filterElementsButton, dispatch]
  );

  const sortUsersByLastName = useCallback(
    (id: number) => {
      setFilterUserButton(id);

      let sortedList = [...itUsers];
      if (id === 0 && filterUserButton == 0) {
        sortedList = sortedList.sort((a, b) =>
          a.lastName.localeCompare(b.lastName)
        );
        console.log("rosnaco");
      }
      if (id === 1 && filterUserButton == 1) {
        sortedList = sortedList.sort((a, b) =>
          b.lastName.localeCompare(a.lastName)
        );
        console.log("malejaco");
      }
      dispatch(setInitialUsersArray(sortedList));
    },
    [filterUserButton, itUsers, dispatch]
  );

  //console.log("user", filterUserButton);

  //   useEffect(() => {
  //     console.log("Coto", searchTextInput);
  //   }, [searchTextInput]);

  useEffect(() => {
    filterByElements(filterElementsButton);
    sortUsersByLastName(filterUserButton);
  }, [filterElementsButton, filterUserButton]);
  useEffect(() => {
    console.log("Jaki stan", searchTextInput);
  }, [searchTextInput]);

  useEffect(() => {
    console.log("Elementow", filterElementsButton);
    console.log("JAK", filterUserButton);
  }, [filterElementsButton, filterUserButton]);

  const useAsyncState = (initialState) => {
    const [arrayData, setArrayData] = useState(initialState);

    const asyncSetArrayData = (value) => {
      return new Promise((resolve) => {
        setArrayData(value);
        setArrayData((current) => {
          resolve(current);
          return current;
        });
      });
    };
    return [arrayData, asyncSetArrayData];
  };

  const [newItUsers, setNewItUsers] = useAsyncState(itUsers);

  //   const reloadUsers = async () => {
  //     await setNewItUsers(itUsers);
  //   };

  useEffect(() => {
    //reloadUsers();
    console.log("Szukam", newItUsers);
  }, [newItUsers]);

  return (
    <div className="flex flex-col">
      <div className="flex flex-row p-2 w-full bg-slate-300">
        <Input
          aria-label="search-bar"
          type="text"
          className="w-[30%]"
          classNames={{ input: "bg-red-600" }}
          placeholder="Szukaj"
          onChange={(event: React.ChangeEvent<HTMLInputElement>) => {
            const searchTerm = event.target.value.toLowerCase();
            //dispatch(setSearchText(searchTerm));
            search(searchTerm, newItUsers);
          }}
        />
        <div className="flex flex-row w-full items-center justify-end gap-2 ">
          <Select
            aria-label="filter-users"
            classNames={{ label: "text-black", description: "text-black" }}
            className="w-[20%] text-black"
            selectedKeys={[filterUserButton.toString()]}
          >
            {alphabeticallyFiltring.map((type) => (
              <SelectItem
                key={type.id}
                classNames={{ title: "text-black" }}
                onClick={() => sortUsersByLastName(type.id)}
              >
                {type.filter}
              </SelectItem>
            ))}
          </Select>

          {/* <Select
            aria-label="filter-users"
            classNames={{ label: "text-black", description: "text-black" }}
            className="w-[20%] text-black"
            //selectedKeys={[filterUserButton.toString()]}
            onChange={() => sortUsersByLastName(type.id)}
          >
            {alphabeticallyFiltring.map((type) => (
              <SelectItem key={type.id} classNames={{ title: "text-black" }}>
                {type.filter}
              </SelectItem>
            ))}
          </Select> */}
          {/* {filterUserButton.map((type))} */}
          <p className="text-black">Elementów na stronie:</p>
          <Select
            aria-label="how-many-elements"
            classNames={{ label: "bg-black", value: "text-black" }}
            className="w-[20%]"
            selectedKeys={[filterElementsButton.toString()]}
          >
            {elementsFiltring.map((type) => (
              <SelectItem
                key={type.id}
                classNames={{ title: "text-black" }}
                onClick={() => filterByElements(type.id)}
              >
                {type.elements}
              </SelectItem>
            ))}
          </Select>
        </div>
      </div>
    </div>
  );
};

export default NewNavbar;

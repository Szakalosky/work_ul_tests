import React from "react";

const Footer = () => {
  return (
    <div className="bg-slate-600 w-full h-[15%] p-4 ">
      Informacje kontaktowe
    </div>
  );
};

export default Footer;
